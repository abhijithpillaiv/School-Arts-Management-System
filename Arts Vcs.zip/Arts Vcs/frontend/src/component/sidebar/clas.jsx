import React from 'react'
import {Link} from 'react-router-dom'

function clas() {
    return (
        <div>
             <ul className="nav sub-group-menu">
              <li className="nav-item">
                <Link to="/class/lkg"  className="nav-link">
                    <i className="fas fa-angle-right"></i>LKG</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/ukg" className="nav-link">
                    <i className="fas fa-angle-right"></i>UKG</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/I" className="nav-link">
                    <i className="fas fa-angle-right"></i>I</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/II" className="nav-link">
                    <i className="fas fa-angle-right"></i>II</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/III" className="nav-link">
                    <i className="fas fa-angle-right"></i>III</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/IV" className="nav-link">
                    <i className="fas fa-angle-right"></i>IV</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/V" className="nav-link">
                    <i className="fas fa-angle-right"></i>V</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/VI" className="nav-link">
                    <i className="fas fa-angle-right"></i>VI</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/VII" className="nav-link">
                    <i className="fas fa-angle-right"></i>VII</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/VIII" className="nav-link">
                    <i className="fas fa-angle-right"></i>VIII</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/IX" className="nav-link">
                    <i className="fas fa-angle-right"></i>IX</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/X" className="nav-link">
                    <i className="fas fa-angle-right"></i>X</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/XI" className="nav-link">
                    <i className="fas fa-angle-right"></i>XI</Link>
            </li>
            <li className="nav-item">
                <Link to="/class/XII" className="nav-link">
                    <i className="fas fa-angle-right"></i>XII</Link>
            </li>
        </ul>
        </div>
    )
}

export default clas
