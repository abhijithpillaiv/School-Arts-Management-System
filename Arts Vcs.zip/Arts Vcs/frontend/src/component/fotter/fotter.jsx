import React from 'react'
function fotter() {
    return (
        <div>
            <footer className="footer-wrap-layout1">
                    <div className="copyright">© Copyrights <span >ADVA</span> 2019. All rights reserved. Designed by <span
                            >@avp</span></div>
                </footer>
            
        </div>
    )
}

export default fotter
