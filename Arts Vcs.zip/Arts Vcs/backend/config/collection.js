module.exports={
    student:'student',
    teacher:'teacher',
}